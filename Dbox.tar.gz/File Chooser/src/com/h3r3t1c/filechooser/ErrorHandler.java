package com.h3r3t1c.filechooser;

import cn.dropbox.client.httpmgmt.HttpClientException;
import cn.dropbox.client.httpmgmt.HttpServerException;

public class ErrorHandler {
	
	public static String getDisplayMessage(HttpServerException e) {
		return "ServerError : " + e.getHttpStatusCode() + " - " + e.getMessage();
	}

	public static CharSequence getDisplayMessage(HttpClientException e) {
		return "Error : " + e.getMessage();
	}

}
