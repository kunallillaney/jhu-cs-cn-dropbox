package com.h3r3t1c.filechooser;

import cn.dropbox.common.rmgmt.model.RType;

public class Option implements Comparable<Option>{
	private String name;
	private String data;
	private String path;
	private RType resType;
	
	public Option(String n,String d,String p, RType rType)
	{
		name = n;
		data = d;
		path = p;
		resType = rType;
	}
	public String getName()
	{
		return name;
	}
	public String getData()
	{
		return data;
	}
	public String getPath()
	{
		return path;
	}
	public RType getResType() {
		return resType;
	}
	@Override
	public int compareTo(Option o) {
		if(this.name != null)
			return this.name.toLowerCase().compareTo(o.getName().toLowerCase()); 
		else 
			throw new IllegalArgumentException();
	}
}
