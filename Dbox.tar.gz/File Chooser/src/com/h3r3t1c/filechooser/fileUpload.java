package com.h3r3t1c.filechooser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ListView;
import android.widget.Toast;
import cn.dropbox.client.httpmgmt.HttpClientException;
import cn.dropbox.client.httpmgmt.HttpHandler;
import cn.dropbox.client.httpmgmt.HttpServerException;




public class fileUpload extends ListActivity {

	private File currentDir;
	private FileArrayAdapter adapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		currentDir = new File("/sdcard/");
		fill(currentDir);
	}

	private void fill(File f) {
		File[] dirs = f.listFiles();
		this.setTitle("Current Dir: " + f.getName());
		List<Option> dir = new ArrayList<Option>();
		List<Option> fls = new ArrayList<Option>();
		try {
			for (File ff : dirs) {
				if (ff.isDirectory())
					dir.add(new Option(ff.getName(), "Folder",ff.getAbsolutePath(), null));
				else {
					fls.add(new Option(ff.getName(), "File Size: "+ ff.length(), ff.getAbsolutePath(), null));
				}
			}
		} catch (Exception e) {

		}
		Collections.sort(dir);
		Collections.sort(fls);
		dir.addAll(fls);
		if (!f.getName().equalsIgnoreCase("sdcard"))
			dir.add(0, new Option("..", "Parent Directory", f.getParent(), null));
		adapter = new FileArrayAdapter(fileUpload.this, R.layout.file_view,dir);
		this.setListAdapter(adapter);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		Option o = adapter.getItem(position);
		if (o.getData().equalsIgnoreCase("folder")
				|| o.getData().equalsIgnoreCase("parent directory")) {
			currentDir = new File(o.getPath());
			fill(currentDir);
		} else {
			onFileClick(o);
		}
	}

	private void onFileClick(Option o) {
		cn.dropbox.common.rmgmt.model.File res=new cn.dropbox.common.rmgmt.model.File();
	
		File f=new File(o.getPath());
		FileInputStream fis;
		try {
			fis = new FileInputStream(f);
			byte[] buf = new byte[(int) f.length()];
			fis.read(buf);
			fis.close();
			res.setFileName(o.getName());
			res.setURI(FileChooser.currentDir.getURI());
			res.setFileSize((int)f.length());
			res.setLastModified(new Date(f.lastModified()));	
			res.setFileContents(buf);

//			fis = new FileInputStream(f);
//			String guessedMimeType = URLConnection.guessContentTypeFromStream(fis);
//			fis.close();
			
			// Reading MIME type
			res.setMimeType("application/pdf");
			
			try {
				HttpHandler.getInstance().executePUT(res);
			} catch (HttpServerException e) {
				if(e.getHttpStatusCode() == 201) {
					Toast.makeText(this, "ServerStatus : " + e.getHttpStatusCode() + " - PUT successful.", Toast.LENGTH_SHORT).show();
					Toast.makeText(this, "Select more files to upload or press Back to go to main menu", Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
			} catch (HttpClientException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}
			//Toast.makeText(this, "File Uploaded: " + o.getName(), Toast.LENGTH_SHORT).show();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
