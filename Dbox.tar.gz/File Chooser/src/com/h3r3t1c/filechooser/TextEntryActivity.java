package com.h3r3t1c.filechooser;

import cn.dropbox.client.httpmgmt.HttpClientException;
import cn.dropbox.client.httpmgmt.HttpHandler;
import cn.dropbox.client.httpmgmt.HttpServerException;
import cn.dropbox.common.rmgmt.api.Resource;
import cn.dropbox.common.rmgmt.model.Directory;
import cn.dropbox.common.rmgmt.model.RType;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TextEntryActivity extends Activity {
    private static final int EDIT_ACTION = 0;
	private EditText et;

    /*
     * (non-Javadoc)
     * @see android.app.Activity#onCreate(android.os.Bundle)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_text_entry);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
                WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
        // title
        try {
            String s = getIntent().getExtras().getString("title");
            if (s.length() > 0) {
                this.setTitle(s);
            }
        } catch (Exception e) {
        	e.printStackTrace();
        }
        // value

        try {
            et = ((EditText) findViewById(R.id.txtValue));
            et.setText(getIntent().getExtras().getString("value"));
        } catch (Exception e) {
        }
        View.OnClickListener input = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                executeDone();
            }
        };
        // button
        ((Button) findViewById(R.id.done)).setOnClickListener(input);
    }

    /* (non-Javadoc)
     * @see android.app.Activity#onBackPressed()
     */
    @Override
    public void onBackPressed() {
        executeDone();
        super.onBackPressed();
    }

    private void executeDone() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("value", TextEntryActivity.this.et.getText().toString());
        
        String value = TextEntryActivity.this.et.getText().toString();
		if (value  != null && value.length() > 0) {
        	Directory res = new Directory();
        	res.setDirName(value);
        	res.setURI(FileChooser.currentDir.getURI());
			try {
				HttpHandler.getInstance().executePUT(res );
				Toast.makeText(this, "New directory created. Please hit refresh", Toast.LENGTH_SHORT).show();
			} catch (HttpServerException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (HttpClientException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}
        	
        }
        
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }

}