package com.h3r3t1c.filechooser;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import cn.dropbox.client.httpmgmt.HttpClientException;
import cn.dropbox.client.httpmgmt.HttpHandler;
import cn.dropbox.client.httpmgmt.HttpServerException;

public class Settings extends Activity {
	private static final int EDIT_ACTION = 0;
	private EditText et;
	private EditText et1;
	private EditText et2;
	private EditText et3;
	static int a;

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.host);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND,
				WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		// title
		try {
			String s = getIntent().getExtras().getString("title");
			if (s.length() > 0) {
				this.setTitle(s);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		// value

		try {
			et = ((EditText) findViewById(R.id.txtValue));
			et.setText(getIntent().getExtras().getString("value"));
			et1 = ((EditText) findViewById(R.id.txtValue1));
			et1.setText(getIntent().getExtras().getString("value1"));
			et2 = ((EditText) findViewById(R.id.editText1));
			et2.setText(getIntent().getExtras().getString("value2"));
			et3 = ((EditText) findViewById(R.id.editText2));
			et3.setText(getIntent().getExtras().getString("value3"));
		} catch (Exception e) {
		}
		View.OnClickListener input = new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				executeDone();
			}
		};
		// button
		((Button) findViewById(R.id.done)).setOnClickListener(input);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onBackPressed()
	 */
	@Override
	public void onBackPressed() {
		executeDone();
		super.onBackPressed();
	}

	private void executeDone() {
		Intent resultIntent = new Intent();
		resultIntent.putExtra("value", Settings.this.et.getText().toString());
		resultIntent.putExtra("value1", Settings.this.et1.getText().toString());
		resultIntent.putExtra("value2", Settings.this.et2.getText().toString());
		resultIntent.putExtra("value3", Settings.this.et3.getText().toString());
		String value = Settings.this.et.getText().toString();
		String value1 = Settings.this.et1.getText().toString();
		String value2 = Settings.this.et2.getText().toString();
		String value3 = Settings.this.et3.getText().toString();
		try {
			a = Integer.parseInt(value1);
			HttpHandler.getInstance()
					.init( value, a);
			setResult(Activity.RESULT_OK, resultIntent);
			HttpHandler.getInstance().performLogin(value2, value3);
			Intent intent = new Intent();
			intent.setClass(this, FileChooser.class);
			startActivity(intent);
		} catch (NumberFormatException e) {
			Toast.makeText(this, " Wrong input", Toast.LENGTH_LONG).show();
		} catch (HttpClientException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (HttpServerException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
	}
}
