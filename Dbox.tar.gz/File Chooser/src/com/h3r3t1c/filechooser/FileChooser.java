package com.h3r3t1c.filechooser;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import cn.dropbox.client.httpmgmt.HttpClientException;
import cn.dropbox.client.httpmgmt.HttpHandler;
import cn.dropbox.client.httpmgmt.HttpServerException;
import cn.dropbox.common.rmgmt.api.Resource;
import cn.dropbox.common.rmgmt.model.Directory;
import cn.dropbox.common.rmgmt.model.File;
import cn.dropbox.common.rmgmt.model.RType;

public class FileChooser extends ListActivity {
	protected static Directory currentDir;
	private FileArrayAdapter adapter;
	protected static String username;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		try {
			Resource serverDir = HttpHandler.getInstance().executeGET(
					"/"+HttpHandler.getInstance().getUserName()+"/", RType.DIRECTORY);

			Directory dir = (Directory) serverDir;
			dir.setURI("/"+HttpHandler.getInstance().getUserName()+"/");
			fill(dir);
		} catch (HttpServerException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (HttpClientException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
	}

	private void populateDir(Directory dir) {

		List<cn.dropbox.common.rmgmt.model.File> testFiles = new ArrayList<cn.dropbox.common.rmgmt.model.File>();
		List<Directory> testDirs = new ArrayList<Directory>();
		for (int i = 0; i < 3; i++) {
			cn.dropbox.common.rmgmt.model.File f = new cn.dropbox.common.rmgmt.model.File();
			f.setFileName("TestFile" + i);
			f.setFileSize(i * 1024);
			f.setLastModified(new Date(new Date().getTime() + i * 1000 * 1000
					* 1000));
			f.setMimeType("Test Mime Type(" + i + ")");
			f.setURI("/uri/file" + i);
			testFiles.add(f);

			Directory d = new Directory();
			d.setDirName("DirName" + i);
			d.setURI("uri/dir" + i);
			d.setLastModified(new Date(new Date().getTime() + i * 1000 * 1000
					* 1000));
			testDirs.add(d);
		}
		dir.setFiles(testFiles);
		dir.setDirectories(testDirs);

	}

	private void fill(Directory d) {
		currentDir = d;
		this.setTitle("Current Dir: " + d.getURI());

		List<Option> dir = new ArrayList<Option>();
		List<Option> fls = new ArrayList<Option>();

		for (cn.dropbox.common.rmgmt.model.File f : d.getFiles()) {
			fls.add(new Option(f.getFileName(), "FileSize:" + f.getFileSize()
					+ " " + Long.toString(f.getLastModified().getTime()), f
					.getURI(), f.getType()));
		}
		for (Directory dr : d.getDirectories()) {
			dir.add(new Option(dr.getDirName(), "FolderItems:"
					+ dr.getDirSize() + " "
					+ Long.toString(dr.getLastModified().getTime()), dr
					.getURI(), d.getType()));
		}
		Collections.sort(dir);
		Collections.sort(fls);
		dir.addAll(fls);
		if (!d.getURI().equalsIgnoreCase("/"+HttpHandler.getInstance().getUserName()+"/")) {
			String currentDirURI = d.getURI();
			int tillIdx = currentDirURI.lastIndexOf(d.getDirName());
			String parentDirURI = currentDirURI.substring(0, tillIdx);
			dir.add(0, new Option("..", "Parent Directory", parentDirURI,
					RType.DIRECTORY));
		}

		adapter = new FileArrayAdapter(FileChooser.this, R.layout.file_view,
				dir);
		this.setListAdapter(adapter);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		Option o = adapter.getItem(position);
		if (o.getResType() == RType.DIRECTORY) {
			Resource serverDir;
			try {
				serverDir = HttpHandler.getInstance().executeGET(
						o.getPath(), o.getResType());
				Directory dir = (Directory) serverDir;
				// dir.setDirName(o.getName());
				dir.setURI(o.getPath());
				// Do a Directory GET operation with URI o.getPath
				// currentDir = new File(o.getPath());
				// populateDir1(dir);
				fill(dir);
			} catch (HttpServerException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (HttpClientException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}

		} else {
			Toast.makeText(this, "Retrieving file " + o.getPath(),
					Toast.LENGTH_SHORT).show();

			Resource res;
			try {
				res = HttpHandler.getInstance().executeGET(o.getPath(),
						RType.FILE);

				File f = (File) res;

				/*Toast.makeText(this,
						"Downloading file to " + "/sdcard/" + f.getFileName(),
						Toast.LENGTH_SHORT).show();
*/
				FileOutputStream fos = new FileOutputStream("/sdcard/"
						+ f.getFileName());
				fos.write(f.getFileContents());
				fos.close();
				Toast.makeText(this,
						"File Downloaded to " + "/sdcard/" + f.getFileName(),
						Toast.LENGTH_SHORT).show();
			} catch (FileNotFoundException e) {
				// e.printStackTrace();
				Toast.makeText(
						this,
						"Failed to download " + o.getPath()
								+ " Reason: " + e.getMessage(),
						Toast.LENGTH_SHORT).show();
			} catch (IOException e) {
				// e.printStackTrace();
				Toast.makeText(
						this,
						"Failed to download " + o.getPath()
								+ " Reason: " + e.getMessage(),
						Toast.LENGTH_SHORT).show();
			} catch (HttpServerException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (HttpClientException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}

			// onFileClick(o);
		}
	}

	private void onFileClick(Option o) {
		Toast.makeText(this, "File Clicked: " + o.getName(), Toast.LENGTH_SHORT)
				.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		/*
		 * menu.add("Create"); menu.add("Upload"); menu.add("Delete");
		 * menu.add("Exit");
		 */
		menu.add(0, 0, 1, R.string.Create);
		menu.add(0, 1, 1, R.string.Upload);
		menu.add(0, 2, 1, R.string.Refresh);
		menu.add(0, 3, 1, R.string.Delete);
		menu.add(0, 4, 1, R.string.app_about);
		menu.add(0, 5, 1, R.string.logout);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		super.onOptionsItemSelected(item);

		switch (item.getItemId()) {
		case 0:
			Intent foo = new Intent(this, TextEntryActivity.class);
			foo.putExtra("New Folder", "");
			this.startActivityForResult(foo, 0);
			
			
			break;
		case 1:
			Intent fo = new Intent();
			fo = new Intent(FileChooser.this, fileUpload.class);
			startActivity(fo);
			
			break;
		case 2:
			Resource serverDir;
			try {
				serverDir = HttpHandler.getInstance().executeGET(
						currentDir.getURI(), RType.DIRECTORY);

				Directory dir = (Directory) serverDir;
				dir.setURI(currentDir.getURI());
				fill(dir);
			} catch (HttpServerException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			} catch (HttpClientException e) {
				Toast.makeText(this, ErrorHandler.getDisplayMessage(e), Toast.LENGTH_LONG).show();
				e.printStackTrace();
			}
			break;
		case 3:
			Intent fof = new Intent();
			fof = new Intent(FileChooser.this, FileDelete.class);
			startActivity(fof);
			break;
		case 4:
			openOptionsDialog();
			break;
		case 5:
			exitOptionsDialog();
			break;
		}
		return true;
	}

	private void openOptionsDialog() {
		new AlertDialog.Builder(this)
				.setTitle(R.string.app_about)
				.setMessage(R.string.app_about_message)
				.setPositiveButton(R.string.str_ok,
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialoginterface, int i) {
							}
						}).show();
	}

	private void exitOptionsDialog() {
		new AlertDialog.Builder(this)
				.setTitle(R.string.logout)
				.setMessage(R.string.ays)
				.setNegativeButton(R.string.str_no,
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialoginterface, int i) {
							}
						})
				.setPositiveButton(R.string.str_ok,
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialoginterface, int i) {
								finish();
							}
						}).show();
	}
}