package com.h3r3t1c.filechooser;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;
import cn.dropbox.client.httpmgmt.HttpClientException;
import cn.dropbox.client.httpmgmt.HttpHandler;
import cn.dropbox.client.httpmgmt.HttpServerException;
import cn.dropbox.common.rmgmt.api.Resource;
import cn.dropbox.common.rmgmt.model.Directory;
import cn.dropbox.common.rmgmt.model.File;
import cn.dropbox.common.rmgmt.model.RType;

public class FileDelete extends ListActivity {
	protected static Directory currentDir;
	private FileArrayAdapter adapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		try {
			Resource serverDir = HttpHandler.getInstance().executeGET(
					FileChooser.currentDir.getURI(), RType.DIRECTORY);

			Directory dir = (Directory) serverDir;
			// dir.setURI("/kunal/");
			fill(dir);
		} catch (HttpServerException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e),
					Toast.LENGTH_LONG).show();
			e.printStackTrace();
		} catch (HttpClientException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e),
					Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
	}

	private void populateDir(Directory dir) {

		List<cn.dropbox.common.rmgmt.model.File> testFiles = new ArrayList<cn.dropbox.common.rmgmt.model.File>();
		List<Directory> testDirs = new ArrayList<Directory>();
		for (int i = 0; i < 3; i++) {
			cn.dropbox.common.rmgmt.model.File f = new cn.dropbox.common.rmgmt.model.File();
			f.setFileName("TestFile" + i);
			f.setFileSize(i * 1024);
			f.setLastModified(new Date(new Date().getTime() + i * 1000 * 1000
					* 1000));
			f.setMimeType("Test Mime Type(" + i + ")");
			f.setURI("/uri/file" + i);
			testFiles.add(f);

			Directory d = new Directory();
			d.setDirName("DirName" + i);
			d.setURI("uri/dir" + i);
			d.setLastModified(new Date(new Date().getTime() + i * 1000 * 1000
					* 1000));
			testDirs.add(d);
		}
		dir.setFiles(testFiles);
		dir.setDirectories(testDirs);

	}

	private void fill(Directory d) {
		currentDir = d;
		this.setTitle("Current Dir: " + d.getURI());

		List<Option> dir = new ArrayList<Option>();
		List<Option> fls = new ArrayList<Option>();

		for (cn.dropbox.common.rmgmt.model.File f : d.getFiles()) {
			fls.add(new Option(f.getFileName(), "FileSize:" + f.getFileSize()
					+ " " + Long.toString(f.getLastModified().getTime()), f
					.getURI(), f.getType()));
		}
		for (Directory dr : d.getDirectories()) {
			dir.add(new Option(dr.getDirName(), "FolderItems:"
					+ dr.getDirSize() + " "
					+ Long.toString(dr.getLastModified().getTime()), dr
					.getURI(), d.getType()));
		}
		dir.addAll(fls);
		if (!d.getURI().equalsIgnoreCase("/"+HttpHandler.getInstance().getUserName()+"/")) {
			String currentDirURI = d.getURI();
			int tillIdx = currentDirURI.lastIndexOf(d.getDirName());
			String parentDirURI = currentDirURI.substring(0, tillIdx);
			dir.add(0, new Option("..", "Parent Directory", parentDirURI,
					RType.DIRECTORY));
		}

		adapter = new FileArrayAdapter(FileDelete.this, R.layout.file_view, dir);
		this.setListAdapter(adapter);
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {

		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		Option o = adapter.getItem(position);

		try {
			HttpHandler.getInstance().executeDelete(o.getPath());
			finish();
			Toast.makeText(this, "Deleted successfully. Please hit refresh",
					Toast.LENGTH_SHORT).show();
		} catch (HttpClientException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e),
					Toast.LENGTH_LONG).show();

			e.printStackTrace();
		} catch (HttpServerException e) {
			Toast.makeText(this, ErrorHandler.getDisplayMessage(e),
					Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
		/*
		 * finish(); Toast.makeText(this,
		 * "Deleted successfully. Please hit refresh",
		 * Toast.LENGTH_SHORT).show(); // onFileClick(o);
		 */}

	private void onFileClick(Option o) {
		// HttpHandler.getInstance().executeDelete(currentDir.getURI());
	}
}
