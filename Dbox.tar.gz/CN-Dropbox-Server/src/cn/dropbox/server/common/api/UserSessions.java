package cn.dropbox.server.common.api;

import java.util.Hashtable;
import java.util.Properties;

public class UserSessions {
    
    // <username, clientcounter>
    public static Hashtable<String, String> userMap = new Hashtable<String, String>();
    
}
