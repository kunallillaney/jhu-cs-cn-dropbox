package cn.dropbox.server.rmgmt.impl;

import cn.dropbox.common.rmgmt.api.Resource;
import cn.dropbox.server.rmgmt.api.ResourceMgr;

public class UserMgr implements ResourceMgr{

	@Override
	public Resource get(String uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void put(Resource resource) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String uri) {
		// TODO Auto-generated method stub
		
	}

}
